orient('landscape')
set(gcf,'units','inches','position',[1 .5 10.5 8.0]);
set( gcf, 'paperunits', 'normal', 'paperposition', [0 0 1 1] )
