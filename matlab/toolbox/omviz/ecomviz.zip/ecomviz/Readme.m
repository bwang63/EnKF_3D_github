%  This is a collection of m-files to manipulate,
%  analyze and visualize NetCDF files generated
%  from Blumberg-Mellor models POM and ECOM.  Some
%  routines require Matlab 5 or higher.
%
%  See the page http://crusty.er.usgs.gov/ecomviz.html
%  for more details and usage information.
%
%  Rich Signell (rsignell@usgs.gov)
